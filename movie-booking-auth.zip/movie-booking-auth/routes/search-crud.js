var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser'); //parses information from POST
router.use(bodyParser.urlencoded({ extended: true }));


var mongoose = require('mongoose');


 //var dbHost = 'mongodb://localhost:27017/test';
// mongoose.connect(dbHost);



var searchSchema = mongoose.Schema({
	searchId:String,
    searchName: String
    

 });
var Search = mongoose.model('Search',searchSchema, 'search');



//Master
 /* router.get('/search', function (req, res) {
    console.log("REACHED city GET FUNCTION ON SERVER");
    Search.find({}, function (err, docs) {
         res.json(docs);         
    });
});
*/

/*
 router.get('/search/:name', function (req, res) {
    console.log("REACHED testing search");
    console.log(req.params.name);
     Search.find({searchName:req.params.name}, function (err, docs) {
     	console.log(docs);
         res.json(docs);
         
    });
 });

*/

  router.get('/search/:name', function (req, res) {
    console.log("REACHED GET ID FUNCTION ON SERVER");
     Search.find({searchName: req.params.name}, function (err, docs) {
         res.json(docs);
         
    });
});


/*// catch 404 and forward to error handler
router.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

*/




/*router.post('/search', function(req, res){
  console.log(req.body);
  var id = req.body.searchId;
  var name = req.body.searchName;
  var search = new Search({
    searchId : id,
    searchName:name   
  });

  search.save(function(err, docs){
    if ( err ) throw err;
    console.log("Book Saved Successfully");
    res.json(docs);
  });

  })


router.put('/search/:name', function(req, res){
    console.log("REACHED PUT");
    console.log(req.body);
    Search.findOneAndUpdate({searchName:req.params.name}, req.body, function (err, data) {
      res.json(data);
    });
})
*/

module.exports=router;