'use strict';

module.exports = function($scope,$rootScope, $http,$location) {
  
  console.log($rootScope.name);
  
  //console.log(MovieList.getMovies());


(function(){
    
    var cityDetails = function($http){
      
      var getCity = function(cityname){
            return $http.get('/city/city')
                        .then(function(response){
                           return response.data; 
                        });
      };
  
      return {
          get: getCity
      };
        
    };
    
    var module = angular.module('movieApp');
    module.factory('cityDetails', cityDetails);
    
}());


   (function(){
    
    var showDetails = function($http){
      
      var getshow = function(showtime){
            return $http.get('/show/show')
                        .then(function(response){
                           return response.data; 
                        });
      };
  
      return {
          get: getshow
      };
        
    };
    
    var module = angular.module('movieApp');
    module.factory('showDetails', showDetails);
    
}());
   (function(){

    var showPlace1 = function($http){

      var getPlace = function(place){
            return $http.get('/showPlace/showPlace')
                        .then(function(response){
                           return response.data;
                        });
      };

      return {
          get: getPlace
      };

    };

    var module = angular.module('movieApp');
    module.factory('showPlace1', showPlace1);

}());


(function(){
    
    var getMovieInfo = function($http){
      
      var getshowinfo = function(showinfo){
            return $http.get('/movieinfo/movieinfo')
                        .then(function(response){
                           return response.data; 
                        });
      };
  
      return {
          get: getshowinfo
      };
        
    };
    
    var module = angular.module('movieApp');
    module.factory('getMovieInfo', getMovieInfo);
    
}());









  //City Methods Starts
  var refresh=function()
  {
        $http.get('/city/city').success(function(response){
            console.log('Admin curd');
            $scope.cityData=response;
            $scope.city="";
        });
  };
  refresh();


$scope.addCity=function()
  {
            console.log('addCity');
            $http.post('/city/city',$scope.city).success(function(response){
                console.log(response);
                console.log("Added successfull");
                refresh();
            });
        };
  




//show Timing Methods starts
var refreshsh=function()
  {
        $http.get('/show/show').success(function(response){
            console.log('show curd');
            $scope.showData=response;
            $scope.show="";
        });
  };
  refreshsh();



 $scope.addShow=function()
  {
            console.log('addShow');
            $http.post('/show/show',$scope.show).success(function(response){
                console.log(response);
                console.log("Added successfull");
                refreshsh();
            });
        };
 






//Show place Methods Starts
var refreshsp=function()
  {
        $http.get('/showPlace/showPlace').success(function(response){
            console.log('showPlace curd');
            $scope.showPlace=response;
            $scope.shp="";
        });
  };
  refreshsp();

$scope.addShowPlace=function()
  {
            console.log('addShow');
            $http.post('/showPlace/showPlace',$scope.shp).success(function(response){
                console.log(response);
                console.log("Added successfull");
                refreshsp();
            });
        };



 var refreshnow = function () {
                            $http.get('/movieinfo/movieinfo').success(function (response) {
                                console.log('READ IS SUCCESSFUL');
                                $scope.nowlist = response;
                                $scope.now = "";
                            });
                        };

                    refreshnow();



$scope.addMovieInfo = function () {
                              console.log($scope.now);
                              $http.post('/movieinfo/movieinfo',$scope.now).success(function (response) {
                                  console.log(response);
                                  console.log("CREATE IS SUCCESSFUL");
                                  refreshnow();
                              });
                          };









var movieObj={};

$scope.getData = function(){
  console.log('Hi Welcome')
  $http.get('http://www.omdbapi.com/?t='+$scope.movieObj.Title+'&y='+$scope.movieObj.Year+'&plot=short&r=json',{data:"aishu"}).success(function (response) {
      console.log(response);
     // var movieObj={};
      for(var key in response){
      if(key=='Title'|| key=='Year' || key== 'Language' || key== 'Poster' || key== 'Genre' || key== 'Director' || key== 'Actors')
      {
      movieObj[key] = response[key];
      }
     
    console.log(movieObj);

      }
           refresh5();
  });
}













 var refresh5 = function () {
                            $http.get('/movie/movie').success(function (response) {
                                console.log('READ IS SUCCESSFUL');
                                $scope.movieObj = response;
                                $scope.moviess = "";
                            });
                        };

                    refresh5();

$scope.addMovie = function () {
                              console.log(movieObj);
                              $http.post('/movie/movie',movieObj).success(function (response) {
                                  console.log(response);
                                  console.log("CREATE IS SUCCESSFUL");
                                  refresh5();
                              });
                          };


var refreshbook = function () {
      $http.get('/booking/booking').success(function (response) {
          console.log('READ IS SUCCESSFUL');
          $scope.bookingList = response;
          $scope.booking = "";
      });
  };

  


refreshbook();

$scope.bookMovieInfo = function () {
console.log($scope.booking);
$http.post('/booking/booking',$scope.booking).success(function (response) {
console.log(response);
console.log("CREATE IS SUCCESSFUL");
  $rootScope.bookingDetails = $scope.booking;
            $location.path('/confirm');
                        // $route.reload();
          

});
};



$scope.removebook=function(id)
{
  console.log(id);
  $http.delete('/booking/booking'+id_id).success(function(response)
  {
    console.log(response);
    console.log("DELETED SUCCESSFULLY");
    refreshbook();
  });
};

/*



  var refresh = function () {
        $http.get('/movie/movie').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.contactlist = response;
            $scope.contact = "";
        });
    };

    refresh();

    $scope.addMovie = function () {
        console.log($scope.contact);
        $http.post('/movie/movie', $scope.contact).success(function (response) {
            console.log(response);
            console.log("CREATE IS SUCCESSFUL");
            refresh();
        });
    };

    $scope.removeMovie = function (id) {
        console.log(id);
        $http.delete('/movie/movie/' + id._id).success(function (response) {
            console.log(response);
            console.log('DELETED SUCCESSFULLY');
            refresh();
        });
    };

    $scope.editMovie = function (id) {
         $http.get('/movie/movie/' + id._id).success(function (response) {
            $scope.contact = response[0];
        });
    };

    $scope.updateMovie = function () {
        console.log("REACHED UPDATE");
        console.log($scope.contact._id);
        $http.put('/movie/movie/' + $scope.contact._id, $scope.contact).success(function (response) {
            console.log(response);
            refresh();
        })
    }*/


}

