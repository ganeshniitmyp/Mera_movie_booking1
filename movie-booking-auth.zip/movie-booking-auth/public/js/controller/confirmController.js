'use strict';

module.exports=function($scope,$rootScope,$http,$location)
{
	//$scope.cancellation='cancellation';
	$scope.booking = $rootScope.bookingDetails;
	console.log($scope.booking);
}