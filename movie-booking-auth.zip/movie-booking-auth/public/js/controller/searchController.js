'use strict';
                                     //
module.exports = function($scope, $http) {
  $scope.search = 'searchpage';



/*var refresh=function()
{
    $http.get('/search/search').success(function(response){
        console.log('search box fun');
        $scope.contactList=response;
        $scope.contact="";
    });
};
*/

$scope.editSearch = function (searchName) {
         $http.get('/search/search/' + $scope.contact.searchName).success(function (response) {
          //console.log(response);
            $scope.contact = response[0];
           

        });
    };

/*
 $scope.editMovie = function (id) {
         $http.get('/city/city/' + id._id).success(function (response) {
            $scope.contact = response[0];
        });
    };
*/

/*


  $scope.search= function () {
        console.log("REACHED UPDATE");
        console.log($scope.contact._name);
        $http.put('/search/searchpost/' + $scope.contact._id, $scope.contact).success(function (response) {
            console.log(response);
            refresh();
        })
    }
*/





};